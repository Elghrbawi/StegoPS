<?php
require_once 'php/config/database.php';
require_once 'php/includes/auth.php';
$auth = new Auth();
if (!$auth->isLoggedIn()) { header('Location: '.SITE_URL.'/index.php'); exit; }
if (isset($_GET['confirm'])) { $auth->logout(); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>StegoPS — Logging Out</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;800&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%;overflow:hidden;background:#050c0e;font-family:'Space Mono',monospace}
.gl-wrap{position:fixed;inset:0;z-index:9999;overflow:hidden;background:#050c0e}
.gl-scan{position:absolute;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,229,200,.03) 2px,rgba(0,229,200,.03) 4px);animation:scanScroll .4s linear infinite;pointer-events:none}
@keyframes scanScroll{from{background-position:0 0}to{background-position:0 4px}}
.gl-r{position:absolute;inset:0;background:#050c0e;mix-blend-mode:screen;opacity:.7;animation:glitchR .65s ease forwards}
.gl-g{position:absolute;inset:0;background:rgba(0,229,200,.15);mix-blend-mode:screen;animation:glitchG .65s ease forwards}
.gl-b{position:absolute;inset:0;background:rgba(124,58,237,.15);mix-blend-mode:screen;animation:glitchB .65s ease forwards}
.gl-line{position:absolute;left:0;right:0;height:2px;background:#00e5c8;box-shadow:0 0 12px #00e5c8,0 0 24px #00e5c8;animation:glitchLine .65s ease forwards}
.gl-line2{position:absolute;left:0;right:0;height:2px;background:#7c3aed;box-shadow:0 0 10px #7c3aed;animation:glitchLine .65s .05s ease forwards;opacity:.5}
.gl-txt{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:13px;letter-spacing:4px;color:#00e5c8;text-transform:uppercase;animation:glitchTxt .65s ease forwards;text-shadow:0 0 20px #00e5c8}
.gl-logo{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700;color:#00e5c8;animation:logoFade .65s ease forwards;text-shadow:0 0 30px rgba(0,229,200,.5)}
.gl-logo span{color:#fff}
@keyframes glitchR{0%{clip-path:inset(0 0 100% 0);transform:translate(-3px,0)}15%{clip-path:inset(10% 0 60% 0);transform:translate(3px,0)}35%{clip-path:inset(60% 0 10% 0);transform:translate(4px,0)}55%,100%{clip-path:inset(0 0 0 0);transform:translate(0,0)}}
@keyframes glitchG{0%{clip-path:inset(100% 0 0 0);transform:translate(3px,0)}30%{clip-path:inset(10% 0 60% 0);transform:translate(-4px,0)}55%,100%{clip-path:inset(0 0 0 0);transform:translate(0,0)}}
@keyframes glitchB{0%{clip-path:inset(50% 0 50% 0)}40%{clip-path:inset(70% 0 0 0)}60%,100%{clip-path:inset(0 0 0 0)}}
@keyframes glitchLine{0%{top:-10px;opacity:1}40%{top:40%;opacity:1}70%{top:90%;opacity:.5}100%{top:110%;opacity:0}}
@keyframes glitchTxt{0%,30%{opacity:0}40%{opacity:1;letter-spacing:8px}55%{opacity:1;letter-spacing:4px}75%,100%{opacity:0}}
@keyframes logoFade{0%,45%{opacity:0}55%{opacity:1;transform:scale(1.05)}70%,100%{opacity:0;transform:scale(1)}}
</style>
</head>
<body>
<div class="gl-wrap">
<div class="gl-scan"></div>
<div class="gl-r"></div>
<div class="gl-g"></div>
<div class="gl-b"></div>
<div class="gl-line"></div>
<div class="gl-line2"></div>
<div class="gl-txt">SESSION TERMINATED</div>
<div class="gl-logo">Steg<span>&#128065;</span>PS</div>
</div>
<script>
setTimeout(function(){window.location.href='<?= SITE_URL ?>/logout.php?confirm=1';},580);
</script>
</body>
</html>